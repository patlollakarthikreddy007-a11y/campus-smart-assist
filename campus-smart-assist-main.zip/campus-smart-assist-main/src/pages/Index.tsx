import CampusAssistant from "@/components/CampusAssistant";

const Index = () => {
  return <CampusAssistant />;
};

export default Index;
